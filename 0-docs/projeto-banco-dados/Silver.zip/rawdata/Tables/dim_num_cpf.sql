CREATE TABLE [rawdata].[dim_num_cpf] (

	[CpfKey] int NULL, 
	[NumCPF] varchar(8000) NULL
);